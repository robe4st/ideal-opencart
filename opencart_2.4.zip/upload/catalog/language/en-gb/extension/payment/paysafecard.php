<?php
// Text
$_['text_title'] = 'Paysafecard';
$_['text_wait'] = 'Please wait!';

// Entry
$_['entry_bank_id'] = '&nbsp;&nbsp;Bank:';

