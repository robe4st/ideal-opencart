<?php
// Text
$_['text_title']           = 'Sofort Banking';
$_['text_wait']            = 'Please wait!';

// Entry
$_['entry_bank_id']        = 'Country';

