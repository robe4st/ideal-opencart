<?php
// Text
$_['text_title'] = 'Bancontact';
$_['text_wait'] = 'Please wait!';