<?php
// Text
$_['text_title'] = 'Mister Cash';
$_['text_wait'] = 'Please wait!';