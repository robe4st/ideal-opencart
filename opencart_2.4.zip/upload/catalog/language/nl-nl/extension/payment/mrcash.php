<?php
// Text
$_['text_title'] = 'Mister Cash';
$_['text_wait'] = 'Even geduld a.u.b.';
