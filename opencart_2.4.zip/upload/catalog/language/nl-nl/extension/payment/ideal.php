<?php
// Text
$_['text_title']           = 'iDEAL';
$_['text_wait']            = 'Even geduld...';

// Entry
$_['entry_bank_id']        = 'Kies je bank';
